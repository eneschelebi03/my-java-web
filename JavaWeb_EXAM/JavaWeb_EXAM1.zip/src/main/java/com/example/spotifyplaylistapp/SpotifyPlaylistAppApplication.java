package com.example.spotifyplaylistapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpotifyPlaylistAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpotifyPlaylistAppApplication.class, args);
    }

}
