package com.example.spotifyplaylistapp.model.enums;

public enum StyleType {
    POP, ROCK, JAZZ
}
